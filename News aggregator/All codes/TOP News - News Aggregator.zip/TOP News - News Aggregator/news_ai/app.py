from flask import Flask, request, jsonify, render_template
from flask_cors import CORS

from google import genai
from google.genai.types import Tool, GenerateContentConfig, GoogleSearch

# Configure API key

# Initialize Gemini client
client = genai.Client(api_key="AIzaSyDQTjjJACI3WHbFO5UR2pHE6Omir1jpDCY")
model_id = "gemini-2.0-flash"

# Define Google Search tool
google_search_tool = Tool(google_search=GoogleSearch())

# Flask app setup
app = Flask(__name__)
CORS(app)


def get_article(headline):
    prompt = f"Write a short, current Indian news article (5-6 sentences) for this headline:\n\"{headline}\""
    response = client.models.generate_content(
        model=model_id,
        contents=prompt,
        config=GenerateContentConfig(
            tools=[google_search_tool],
            response_modalities=["TEXT"],
            system_instruction="You are a helpful assistant that writes news articles based on provided headlines. You must return just the article, NO extra text, NO salutations, NO 'here is content you asked for'."
        )
    )
    return response.candidates[0].content.parts[0].text


def get_headlines(prompt):
    response = client.models.generate_content(
        model=model_id,
        contents=prompt,
        config=GenerateContentConfig(
            tools=[google_search_tool],
            response_modalities=["TEXT"]
        )
    )
    headlines_text = response.candidates[0].content.parts[0].text
    headlines_list = [line.strip() for line in headlines_text.split('\n') if line.strip()]
    cleaned_headlines = []
    for headline in headlines_list:
        cleaned = headline.lstrip('0123456789. •-').strip()
        if cleaned:
            cleaned_headlines.append(cleaned)
    return cleaned_headlines


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/news")
def news():
    category = request.args.get("category", "National")
    prompt = f"Give me the top 5 {category} news headlines in India"
    headlines = get_headlines(prompt)
    return jsonify({"headlines": headlines})


@app.route("/article")
def article():
    headline = request.args.get("headline", "")
    article = get_article(headline)
    return jsonify({"article": article})


if __name__ == "__main__":
    app.run(debug=True)
